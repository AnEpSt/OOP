/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "mytextbrowser.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *linesearch;
    QLineEdit *linesearch1;
    QLineEdit *linesearch2;
    QLineEdit *linesearch3;
    QLineEdit *linesearch4;
    QLineEdit *linesearch5;
    QPushButton *reviewbutton;
    QPushButton *searchButton;
    MyTextbrowser *textBrowser;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1039, 658);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName("verticalLayout");
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        linesearch = new QLineEdit(centralwidget);
        linesearch->setObjectName("linesearch");

        horizontalLayout_2->addWidget(linesearch);

        linesearch1 = new QLineEdit(centralwidget);
        linesearch1->setObjectName("linesearch1");

        horizontalLayout_2->addWidget(linesearch1);

        linesearch2 = new QLineEdit(centralwidget);
        linesearch2->setObjectName("linesearch2");

        horizontalLayout_2->addWidget(linesearch2);

        linesearch3 = new QLineEdit(centralwidget);
        linesearch3->setObjectName("linesearch3");

        horizontalLayout_2->addWidget(linesearch3);

        linesearch4 = new QLineEdit(centralwidget);
        linesearch4->setObjectName("linesearch4");

        horizontalLayout_2->addWidget(linesearch4);

        linesearch5 = new QLineEdit(centralwidget);
        linesearch5->setObjectName("linesearch5");

        horizontalLayout_2->addWidget(linesearch5);

        reviewbutton = new QPushButton(centralwidget);
        reviewbutton->setObjectName("reviewbutton");

        horizontalLayout_2->addWidget(reviewbutton);

        searchButton = new QPushButton(centralwidget);
        searchButton->setObjectName("searchButton");

        horizontalLayout_2->addWidget(searchButton);


        verticalLayout->addLayout(horizontalLayout_2);

        textBrowser = new MyTextbrowser(centralwidget);
        textBrowser->setObjectName("textBrowser");

        verticalLayout->addWidget(textBrowser);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1039, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);
        QObject::connect(searchButton, SIGNAL(clicked()), MainWindow, SLOT(add()));
        QObject::connect(reviewbutton, SIGNAL(clicked()), MainWindow, SLOT(choose()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        reviewbutton->setText(QCoreApplication::translate("MainWindow", "\320\276\320\261\320\267\320\276\321\200", nullptr));
        searchButton->setText(QCoreApplication::translate("MainWindow", "\320\277\320\276\320\270\321\201\320\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
