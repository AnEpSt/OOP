#include "circle.h"
#include <QPainter>
Circle::Circle(const QPoint& center, int radius): cir_centre(center), cir_rad(radius) {}
void Circle::paint(QPainter& painter) const {
    painter.save();
    painter.setPen(Qt::black);
    painter.setBrush(Qt::blue);
    painter.drawEllipse(cir_centre, cir_rad, cir_rad);

    painter.restore();

}
