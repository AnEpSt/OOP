#ifndef FIGUREWIDGET_H
#define FIGUREWIDGET_H
#include <QWidget>
#include <vector>
#include <memory>
#include "Figure.h"
class FigureWidget : public QWidget {
    Q_OBJECT
public:
    explicit FigureWidget(QWidget* parent = nullptr);
    void paintEvent(QPaintEvent* event) override;

private:
    std::vector<std::unique_ptr<Figure>> figures;
};
#endif // FIGUREWIDGET_H
