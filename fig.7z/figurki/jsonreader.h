#ifndef JSONREADER_H
#define JSONREADER_H
#include <fstream>
#include "json.hpp"
#include "figure.h"
using json =  nlohmann::json;
class JsonReader
{
private:
    std::fstream fin;
public:
    JsonReader(const std::string& filename);
    bool is_open() const ;
    std::vector<std::unique_ptr<Figure>> readFig();
};
#endif // JSONREADER_H
