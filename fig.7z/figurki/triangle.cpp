#include "triangle.h"
Triangle::Triangle(std::array<QPoint,3>& a_): a1(a_) {}
void Triangle::paint(QPainter& painter) const {
    painter.save();
    painter.setPen(Qt::red);
    painter.drawLine(a1[0], a1[1]);
    painter.drawLine(a1[1], a1[2]);
    painter.drawLine(a1[2], a1[0]);
    painter.restore();

}
