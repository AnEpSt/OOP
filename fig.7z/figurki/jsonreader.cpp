#include "jsonreader.h"
#include  <fstream>
#include "circle.h"
#include "rectangle.h"
#include "triangle.h"
JsonReader::JsonReader(const std::string& filename){
    fin.open(filename);
}
bool JsonReader::is_open() const{
    return fin.is_open();
}
std::vector<std::unique_ptr<Figure>> JsonReader::readFig(){
    std::vector<std::unique_ptr<Figure>> figures;

    if (!is_open()) {
        return figures;
    }
    try {
        json j;
        fin >> j;
        for (const auto& e :j){
            std::string type = e["type"].get<std::string>();
            if (type == "circle"){
                int x = e["X"].get<int>();
                int y = e["Y"].get<int>();
                int rad = e["rad"].get<float>();
                figures.push_back(std::make_unique<Circle>(QPoint(x, y), rad));
            }
            else if (type == "rectangle") {
                int x = e["X"].get<int>();
                int y = e["Y"].get<int>();
                int w = e["width"].get<float>();
                int h = e["height"].get<float>();
                figures.push_back(std::make_unique<Rectangle>(QRect(x, y, w, h)));
            }
            else if (type == "triangle") {
                std::array<QPoint,3> m;
                int x = e["X1"].get<int>();
                int y = e["Y1"].get<int>();
                m[0] =  (QPoint(x, y));
                int w = e["X2"].get<int>();
                int h = e["Y2"].get<int>();
                m[1] =(QPoint(w, h));
                int j = e["X3"].get<int>();
                int k = e["Y3"].get<int>();
                m[2] =(QPoint(j, k));
                figures.push_back(std::make_unique<Triangle>(m));
            }
        }
    }
    catch (const json::exception& e) {

}
return figures;
}
