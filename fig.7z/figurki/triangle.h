#ifndef TRIANGLE_H
#define TRIANGLE_H
#include "Figure.h"
#include <QPoint>
class Triangle : public Figure
{
private:
    std::array<QPoint, 3> a1{};
public:
    Triangle(std::array<QPoint,3>& a);
    void paint(QPainter& painter) const ;
};

#endif // TRIANGLE_H
