#include "FigureWidget.h"
#include <QVBoxLayout>
#include "Figure.h"
#include "jsonreader.h"
#include <QPainter>
FigureWidget::FigureWidget(QWidget* parent) : QWidget(parent) {
    JsonReader reader("fig.json");
    if (reader.is_open()){
        figures = reader.readFig();
    }
}
void FigureWidget::paintEvent(QPaintEvent*){
    QPainter painter(this);
    for (const auto& fig:figures){
        fig->paint(painter);
    }
}
