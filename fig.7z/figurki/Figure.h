#ifndef FIGURE_H
#define FIGURE_H
#include <QPainter>
#include <QJsonObject>
#include <vector>
#include <string>

class Figure {
public:
    virtual ~Figure(){}
    virtual void paint(QPainter& painter) const = 0;
};



#endif // FIGURE_H
