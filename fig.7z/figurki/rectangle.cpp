#include "rectangle.h"
#include <QPainter>

Rectangle::Rectangle(const QRect& rect)
    : m_rect(rect) {}

void Rectangle::paint(QPainter& painter) const {
    painter.save();


    QPen pen(Qt::black, 2);
    pen.setStyle(Qt::SolidLine);
    painter.setPen(pen);

    // Настраиваем заливку
    painter.setBrush(QBrush(Qt::green, Qt::SolidPattern));

    // Рисуем прямоугольник
    painter.drawRect(m_rect);

    painter.restore();
}
